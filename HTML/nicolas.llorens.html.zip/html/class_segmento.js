var class_segmento =
[
    [ "Segmento", "class_segmento.html#af8ce1463824db8cd38084f4f75d3b192", null ],
    [ "Segmento", "class_segmento.html#a325e58fb03daa6d14ceeb3c4759b042d", null ],
    [ "Segmento", "class_segmento.html#a18576aa0c0d5d4200e23b84d760b5aa3", null ],
    [ "~Segmento", "class_segmento.html#a7a9ecb38532ea633aacdaa90be7c4769", null ],
    [ "longitud", "class_segmento.html#a61c7347eb37045bef7655d3db24d7fd9", null ],
    [ "operator!=", "class_segmento.html#a77db9ed1b0a50b2cc1783c57a25f359a", null ],
    [ "operator<", "class_segmento.html#a780e43a2c06be2e098753cd5133f630b", null ],
    [ "operator<=", "class_segmento.html#acc183ac638eab6f484d17ced4f66cf8e", null ],
    [ "operator=", "class_segmento.html#aee5b332a00494aa3963fe5a1496ab3f4", null ],
    [ "operator==", "class_segmento.html#a1f1e5977425950af37d4ca52761d381a", null ],
    [ "operator>", "class_segmento.html#a01c2aa376384c7a75ef22196db361d2e", null ],
    [ "operator>=", "class_segmento.html#a74e0ca47b9bf2316a0f55351529380f6", null ],
    [ "print", "class_segmento.html#ac6f9e53987e915d2d0b6847aeb8e49ed", null ],
    [ "ubic", "class_segmento.html#aeb7bfd4dcac3a1a000a33582861e0d50", null ]
];