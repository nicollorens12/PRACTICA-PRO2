var searchData=
[
  ['pos_144',['pos',['../_a_p_u_n_t_e_s_8txt.html#afad21849931a4684083facc2ef23fb28',1,'APUNTES.txt']]],
  ['pr�ctica_145',['pr�ctica',['../lee__me_8txt.html#aa41b3b900967379d0ba2a6ab7c01a32f',1,'lee_me.txt']]]
];
