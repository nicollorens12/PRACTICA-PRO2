var searchData=
[
  ['t_5fsize_130',['t_size',['../class_area___magatzem.html#a47a11569a59c062a7071c3b6999382c0',1,'Area_Magatzem']]]
];
