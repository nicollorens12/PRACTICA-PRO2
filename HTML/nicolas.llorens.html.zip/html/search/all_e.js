var searchData=
[
  ['segmento_55',['Segmento',['../class_segmento.html',1,'Segmento'],['../class_segmento.html#af8ce1463824db8cd38084f4f75d3b192',1,'Segmento::Segmento()'],['../class_segmento.html#a325e58fb03daa6d14ceeb3c4759b042d',1,'Segmento::Segmento(const Ubicacion &amp;u, int l)'],['../class_segmento.html#a18576aa0c0d5d4200e23b84d760b5aa3',1,'Segmento::Segmento(const Segmento &amp;s)']]],
  ['segmento_2ehh_56',['Segmento.hh',['../_segmento_8hh.html',1,'']]],
  ['size_57',['size',['../_a_p_u_n_t_e_s_8txt.html#ac3395a9381665625bbf1d1258f3ffecf',1,'APUNTES.txt']]]
];
