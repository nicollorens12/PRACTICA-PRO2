var searchData=
[
  ['altura_1',['altura',['../class_area___magatzem.html#a5658438260cd934c77b4bf6aae74d4f4',1,'Area_Magatzem']]],
  ['apuntes_2etxt_2',['APUNTES.txt',['../_a_p_u_n_t_e_s_8txt.html',1,'']]],
  ['area_5fespera_3',['Area_Espera',['../class_area___espera.html',1,'Area_Espera'],['../class_area___espera.html#a260d02d0043e1fd9d8ce6e08de930c63',1,'Area_Espera::Area_Espera()']]],
  ['area_5fespera_2ehh_4',['Area_Espera.hh',['../_area___espera_8hh.html',1,'']]],
  ['area_5fmagatzem_5',['Area_Magatzem',['../class_area___magatzem.html',1,'Area_Magatzem'],['../class_area___magatzem.html#ac2edce567d03fc5818fab838bac03b24',1,'Area_Magatzem::Area_Magatzem()']]],
  ['area_5fmagatzem_2ehh_6',['Area_Magatzem.hh',['../_area___magatzem_8hh.html',1,'']]]
];
