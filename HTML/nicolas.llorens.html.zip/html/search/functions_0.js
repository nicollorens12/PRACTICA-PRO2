var searchData=
[
  ['altura_89',['altura',['../class_area___magatzem.html#a5658438260cd934c77b4bf6aae74d4f4',1,'Area_Magatzem']]],
  ['area_5fespera_90',['Area_Espera',['../class_area___espera.html#a260d02d0043e1fd9d8ce6e08de930c63',1,'Area_Espera']]],
  ['area_5fmagatzem_91',['Area_Magatzem',['../class_area___magatzem.html#ac2edce567d03fc5818fab838bac03b24',1,'Area_Magatzem']]]
];
