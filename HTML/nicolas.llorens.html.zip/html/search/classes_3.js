var searchData=
[
  ['segmento_77',['Segmento',['../class_segmento.html',1,'']]]
];
