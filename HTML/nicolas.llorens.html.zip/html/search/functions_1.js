var searchData=
[
  ['best_5ffit_92',['best_fit',['../class_area___magatzem.html#ab5ae19eb73f331fd0ac35e0a118ba20a',1,'Area_Magatzem']]],
  ['best_5ffit_5faux_93',['best_fit_aux',['../class_hilera.html#ab97ec83e150719182baf7f3a061822c2',1,'Hilera']]]
];
