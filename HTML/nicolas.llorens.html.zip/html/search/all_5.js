var searchData=
[
  ['enunciado_15',['enunciado',['../lee__me_8txt.html#af77b8b1411b7e49634c689910f315624',1,'lee_me.txt']]],
  ['es_5fvalid_16',['es_valid',['../class_area___magatzem.html#a96efdbba894223bcdec9d2cdc51f0616',1,'Area_Magatzem']]]
];
