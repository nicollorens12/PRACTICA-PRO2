var searchData=
[
  ['filas_17',['filas',['../class_area___magatzem.html#a4f790ae3af2899a47b243aa7536113ff',1,'Area_Magatzem']]]
];
