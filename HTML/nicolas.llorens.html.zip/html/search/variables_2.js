var searchData=
[
  ['enunciado_143',['enunciado',['../lee__me_8txt.html#af77b8b1411b7e49634c689910f315624',1,'lee_me.txt']]]
];
