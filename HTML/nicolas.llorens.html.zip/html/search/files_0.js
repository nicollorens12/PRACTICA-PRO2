var searchData=
[
  ['apuntes_2etxt_79',['APUNTES.txt',['../_a_p_u_n_t_e_s_8txt.html',1,'']]],
  ['area_5fespera_2ehh_80',['Area_Espera.hh',['../_area___espera_8hh.html',1,'']]],
  ['area_5fmagatzem_2ehh_81',['Area_Magatzem.hh',['../_area___magatzem_8hh.html',1,'']]]
];
