var searchData=
[
  ['area_5fespera_72',['Area_Espera',['../class_area___espera.html',1,'']]],
  ['area_5fmagatzem_73',['Area_Magatzem',['../class_area___magatzem.html',1,'']]]
];
