var searchData=
[
  ['ubicacion_78',['Ubicacion',['../class_ubicacion.html',1,'']]]
];
