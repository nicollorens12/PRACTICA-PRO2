var searchData=
[
  ['x_147',['x',['../_a_p_u_n_t_e_s_8txt.html#aa7095101004ea3d5cf597740ed86e00e',1,'APUNTES.txt']]]
];
