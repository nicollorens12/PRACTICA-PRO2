var searchData=
[
  ['es_5fvalid_97',['es_valid',['../class_area___magatzem.html#a96efdbba894223bcdec9d2cdc51f0616',1,'Area_Magatzem']]]
];
