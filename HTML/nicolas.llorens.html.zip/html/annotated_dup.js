var annotated_dup =
[
    [ "Area_Espera", "class_area___espera.html", "class_area___espera" ],
    [ "Area_Magatzem", "class_area___magatzem.html", "class_area___magatzem" ],
    [ "Cjt_Contenidors", "class_cjt___contenidors.html", "class_cjt___contenidors" ],
    [ "Contenedor", "class_contenedor.html", "class_contenedor" ],
    [ "Hilera", "class_hilera.html", "class_hilera" ],
    [ "Segmento", "class_segmento.html", "class_segmento" ],
    [ "Ubicacion", "class_ubicacion.html", "class_ubicacion" ]
];