var class_area___magatzem =
[
    [ "Area_Magatzem", "class_area___magatzem.html#ac2edce567d03fc5818fab838bac03b24", null ],
    [ "~Area_Magatzem", "class_area___magatzem.html#a86ea00e4be627ef840575ed17facfa56", null ],
    [ "altura", "class_area___magatzem.html#a5658438260cd934c77b4bf6aae74d4f4", null ],
    [ "best_fit", "class_area___magatzem.html#ab5ae19eb73f331fd0ac35e0a118ba20a", null ],
    [ "es_valid", "class_area___magatzem.html#a96efdbba894223bcdec9d2cdc51f0616", null ],
    [ "filas", "class_area___magatzem.html#a4f790ae3af2899a47b243aa7536113ff", null ],
    [ "inserta_contenedor", "class_area___magatzem.html#ad875df627b7a5d12517e724ff3b520a3", null ],
    [ "plazas", "class_area___magatzem.html#a19c4ecce3c9feb1230dced02e6405682", null ],
    [ "print_area_almacenaje", "class_area___magatzem.html#a4d668d2022dc3f27a85e50215d987345", null ],
    [ "print_contenedor_ocupa", "class_area___magatzem.html#a96d76b1670786d193a9872489d15d74a", null ],
    [ "print_huecos", "class_area___magatzem.html#a0e334c5100bb3aeecd3be6565cc951b7", null ],
    [ "print_longitud", "class_area___magatzem.html#acdad944319d968df20d5559610958e59", null ],
    [ "print_num_hileras", "class_area___magatzem.html#aefe63ddc0e9cf5027482ef82c54981f9", null ],
    [ "print_num_pisos", "class_area___magatzem.html#abfff667d6e8751f444aed8d71ba2a8fd", null ],
    [ "print_num_plazas", "class_area___magatzem.html#a6022f4397a47f075575dfe53c49b7abf", null ],
    [ "print_ubi", "class_area___magatzem.html#a749652e3fd00e3e930ea5c12f319255e", null ],
    [ "retira_contenidor", "class_area___magatzem.html#a89bb6d1373d7b00ac88c1144bd7d1f51", null ],
    [ "t_size", "class_area___magatzem.html#a47a11569a59c062a7071c3b6999382c0", null ]
];