var files_dup =
[
    [ "Area_Espera.hh", "_area___espera_8hh.html", [
      [ "Area_Espera", "class_area___espera.html", "class_area___espera" ]
    ] ],
    [ "Area_Magatzem.hh", "_area___magatzem_8hh.html", [
      [ "Area_Magatzem", "class_area___magatzem.html", "class_area___magatzem" ]
    ] ],
    [ "Cjt_Contenidors.hh", "_cjt___contenidors_8hh.html", [
      [ "Cjt_Contenidors", "class_cjt___contenidors.html", "class_cjt___contenidors" ]
    ] ],
    [ "Contenedor.hh", "_contenedor_8hh.html", [
      [ "Contenedor", "class_contenedor.html", "class_contenedor" ]
    ] ],
    [ "Hilera.hh", "_hilera_8hh.html", "_hilera_8hh" ],
    [ "program.cc", "program_8cc.html", "program_8cc" ],
    [ "Segmento.hh", "_segmento_8hh.html", [
      [ "Segmento", "class_segmento.html", "class_segmento" ]
    ] ],
    [ "Ubicacion.hh", "_ubicacion_8hh.html", [
      [ "Ubicacion", "class_ubicacion.html", "class_ubicacion" ]
    ] ]
];